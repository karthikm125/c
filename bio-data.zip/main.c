/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    printf("Name :Karthik M \n" );
    printf("Age :20 \n");
    printf("Email :kartikmurali125@gmail.com \n");
    printf("Phone :8089763935 \n");
    printf("Place :Calicut \n");
    printf("Gender :Male");

    return 0;
}
