/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char c;
    printf("Enter a letter:");
    scanf(" %c", &c);
    if(c=='a' ||c=='e'||c=='i'||c=='o'||c =='u'){
        printf("the word is an vowel");
    }
    else{
        printf("the word is a constant");
    }

    return 0;
}