/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void prime();
void main()

{
    printf("PRIME NUMBERS OR NOT\n");
    prime();
}
void prime(){
     int num;
   int isprime=1;
   printf("Enter the number to check if it is prime or not: ");
   scanf("%d",&num);
   if(num<=1){
       isprime=0;
   }else{
       int divisor=num/2;
       while(divisor>1){
           if(num%divisor==0){
               isprime=0;
               break;
           }
           divisor--;
       }
   }
   if(isprime){
       printf("%d is a prime number.\n",num);
   }else{
       printf("%d is not a prime number.\n",num);
   }
}
