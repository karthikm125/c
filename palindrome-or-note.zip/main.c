/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    
    int n, r = 0, o;

    printf("Enter a number: ");
    scanf("%d", &n);

    o = n;
    while (n != 0) {
        int d = n % 10;
        r = r * 10 + d;
        n /= 10;
    }

    if (o == r) {
        printf("%d is a palindrome.\n", o);
    } else {
        printf("%d is not a palindrome.\n", o);
    }

    return 0;
}