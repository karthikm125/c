/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int m;
    printf("Enter M:");
    scanf("%d",&m);
    if(m>0)
    {
        printf("N=1");
    }
    else if(m==0)
    {
        printf("N=0");
    }
    else
    {
        printf("N=-1");
    }

    return 0;
}
